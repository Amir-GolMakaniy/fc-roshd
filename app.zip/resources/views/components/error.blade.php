@props(['name'])

@error($name) <span {{ $attributes }}>{{ $message }}</span> @enderror