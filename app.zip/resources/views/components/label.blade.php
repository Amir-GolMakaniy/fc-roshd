@props(['name','value'])

<label for="{{ $name }}" {{ $attributes }}>{{ $value }}</label>