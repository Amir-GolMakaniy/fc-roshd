<div>
    <h1>home</h1>
</div>
<?php /**PATH D:\Users\amir-goli\Desktop\gym\resources\views/livewire/home.blade.php ENDPATH**/ ?>