<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo e($title ?? 'Page Title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.rtl.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/persian.datepicker.css')); ?>"/>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/persian.date.js')); ?>"></script>
    <script src="<?php echo e(asset('js/persian.datepicker.js')); ?>"></script>
</head>
<body>
<?php echo e($slot); ?>

<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script>
    function input(number) {
        let value = number.value;
        value = value.replace(/\D/g, '');
        let formattedValue = '';
        while (value.length > 3) {
            formattedValue = ',' + value.slice(-3) + formattedValue;
            value = value.slice(0, value.length - 3);
        }
        formattedValue = value + formattedValue;
        number.value = formattedValue;
    }
</script>
</body>
</html>
<?php /**PATH D:\Users\amir-goli\Desktop\gym\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>